-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Jan 20, 2015 as 02:20 PM
-- Versão do Servidor: 5.1.36
-- Versão do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `capsad`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pacientes`
--

CREATE TABLE IF NOT EXISTS `pacientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `dn` date NOT NULL,
  `genero` varchar(10) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefones` varchar(140) NOT NULL,
  `pai` varchar(60) NOT NULL,
  `mae` varchar(60) NOT NULL,
  `cns` varchar(20) NOT NULL,
  `rg` varchar(15) NOT NULL,
  `orgaorg` varchar(30) NOT NULL,
  `emissaorg` date NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `naturalidade` varchar(60) NOT NULL,
  `certidao` varchar(100) NOT NULL,
  `demanda` varchar(15) NOT NULL,
  `cidp` varchar(5) NOT NULL,
  `cids` varchar(5) NOT NULL,
  `inicio` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `pacientes`
--

