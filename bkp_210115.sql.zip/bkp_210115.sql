-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Jan 21, 2015 as 05:38 PM
-- Versão do Servidor: 5.1.36
-- Versão do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `capsad`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimentos`
--

CREATE TABLE IF NOT EXISTS `atendimentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `atendimento` varchar(30) NOT NULL,
  `codigo` varchar(15) NOT NULL,
  `profissionais` longtext NOT NULL,
  `outros` longtext NOT NULL,
  `data` date NOT NULL,
  `pacientes` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `atendimentos`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `pacientes`
--

CREATE TABLE IF NOT EXISTS `pacientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `dn` date NOT NULL,
  `genero` varchar(10) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefones` varchar(140) NOT NULL,
  `pai` varchar(60) NOT NULL,
  `mae` varchar(60) NOT NULL,
  `cns` varchar(20) NOT NULL,
  `rg` varchar(15) NOT NULL,
  `orgaorg` varchar(30) NOT NULL,
  `emissaorg` date NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `naturalidade` varchar(60) NOT NULL,
  `certidao` varchar(100) NOT NULL,
  `demanda` varchar(15) NOT NULL,
  `cidp` varchar(5) NOT NULL,
  `cids` varchar(5) NOT NULL,
  `inicio` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `pacientes`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `procedimentos`
--

CREATE TABLE IF NOT EXISTS `procedimentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(12) NOT NULL,
  `procedimento` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `procedimentos`
--

INSERT INTO `procedimentos` (`id`, `codigo`, `procedimento`) VALUES
(1, '0301080232', 'Acolhimento inicial'),
(2, '0301020208', 'Atendimento individual'),
(3, '0301080224', 'Atendimento familiar'),
(4, '0301080216', 'Atendimento em grupo'),
(5, '0301080283', 'Práticas expressivas'),
(6, '0301080275', 'Práticas corporais'),
(7, '0301080194', 'Acolhimento diurno'),
(8, '0301080038', 'Acolhimento em terceiro turno'),
(9, '0301080356', 'Promoção no território'),
(10, '0301080348', 'Reabilitação psicossocial'),
(11, '0301080240', 'Atendimento domiciliar'),
(12, '0301080291', 'Atenção a crise'),
(13, '0301080364', 'Acompanhamento em comunidade terapêutica');

-- --------------------------------------------------------

--
-- Estrutura da tabela `profissionais`
--

CREATE TABLE IF NOT EXISTS `profissionais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(20) CHARACTER SET latin1 NOT NULL,
  `sobrenome` varchar(60) CHARACTER SET latin1 NOT NULL,
  `matricula` varchar(10) CHARACTER SET latin1 NOT NULL,
  `cargo` varchar(50) CHARACTER SET latin1 NOT NULL,
  `cbo` varchar(10) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- Extraindo dados da tabela `profissionais`
--

INSERT INTO `profissionais` (`id`, `nome`, `sobrenome`, `matricula`, `cargo`, `cbo`) VALUES
(1, 'Adriana', 'de Souza Silva Lopes', '28.163', 'Assistente social', '2516-05'),
(2, 'Ana Lúcia', 'Basílio Ferreira Togeiro', '12.782', 'Psicóloga', '2515-10'),
(3, 'Ananda', 'de Moura Resende', '27.903', 'Psicóloga', '2515-10'),
(4, 'André', 'de Queirós Carneiro da Silva', '9.508', 'Médico psiquiatra', '2251-33'),
(5, 'Carla', 'Rocha Rezende Mota', '44.595', 'Assistente social', '2516-05'),
(6, 'Fátima', 'Cristina de Oliveira Candeco', '500.006', 'Assistente social', '2516-05'),
(7, 'Franthesca', 'Mota Manhães', '44.275', 'Porteira', '5174-10'),
(8, 'Henrique', 'dos Santos Pazzini', '27.074', 'Médico psiquiatra', '2251-33'),
(9, 'Jean', 'da Silva Corrêa', '17.988', 'Operador de computador', '4121-10'),
(10, 'João', 'Batista de Mattos', '007669', 'Barbeiro', '5161-05'),
(11, 'Jônatas', 'Mota Rictor', '10.644', 'Recepcionista de unidade de saúde', '4221-10'),
(12, 'Letícia', 'Pereira Rodrigues', '27.571', 'Auxiliar de enfermagem', '3222-30'),
(13, 'Mirella', 'Gregio de Araújo Corrêa', '27.532', 'Assistente social', '2516-05'),
(14, 'Natália', 'Villaça Alves', '10.559', 'Enfermeira', '2235-05'),
(15, 'Selma', 'Gomes de Souza', '27.583', 'Auxiliar de enfermagem', '3222-30'),
(16, 'Silvia', 'Helena Miranda Melo', '39.009', 'Psicóloga', '2515-10'),
(17, 'Vanda', 'Cristina dos Santos Almeida', '4300', 'Assistente de Administração e Logística', '4110-10');
